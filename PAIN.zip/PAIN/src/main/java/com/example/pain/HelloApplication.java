package com.example.pain;

import javafx.embed.swing.SwingFXUtils;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritablePixelFormat;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javax.imageio.ImageIO;
import java.nio.IntBuffer;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;

import java.io.File;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Image pic=new Image("https://static.wikia.nocookie.net/nicos-nextbots/images/a/a6/WiseMysticalTree.png/revision/latest?cb=20230413115654");
        ImageView imageView=new ImageView(pic);
        imageView.setX(20);
        imageView.setY(25);
        FileChooser choose=new FileChooser();
        imageView.setPreserveRatio(true);
        choose.setTitle("Save");
        choose.getExtensionFilters().addAll(new ExtensionFilter("PNG files", "*.png*"));


        Group group=new Group(imageView);
        Scene scene = new Scene(group, 320, 240);




        ButtonBar bar=new ButtonBar();
        Button cButton=new Button("Close");
        Button saveButton=new Button("Save");
        Button saveAsButton=new Button("Save As...");
        bar.getButtons().addAll(cButton,saveButton,saveAsButton);
        group.getChildren().add(bar);
        saveAsButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                File f = choose.showSaveDialog(stage);
                saveAsImage(f,imageView);
            }


        });
        stage.setScene(scene);
        stage.show();

        EventHandler<ActionEvent> event =new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                stage.close();
            }
        };

        EventHandler<ActionEvent> saving =new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                saveImage(pic);
            }
        };

        cButton.setOnAction(event);
        saveButton.setOnAction(saving);

    }

    public static void main(String[] args) {
        launch(args);
    }

   private void saveImage(Image image){
        File f= new File("C:/250/WiseMysticalTree.png");
        BufferedImage bImage=SwingFXUtils.fromFXImage(image,null);
        try{
            ImageIO.write(bImage,"png",f);
        }catch(IOException e){
            throw new RuntimeException(e);
        }
    }
    private void saveAsImage(File f , ImageView imageView){

        BufferedImage bImage=SwingFXUtils.fromFXImage(imageView.getImage(),null);
        if (f != null) {
            try {
                ImageIO.write(bImage, "png", f);

            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
    }
}}
