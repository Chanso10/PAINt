package com.example.pain;

import javafx.embed.swing.SwingFXUtils;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.canvas.Canvas;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Scene;

import javafx.scene.image.ImageView;
import javafx.scene.image.WritablePixelFormat;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javax.imageio.ImageIO;
import javafx.scene.paint.Color;
import java.nio.IntBuffer;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import java.io.File;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class HelloApplication extends Application {
    private int width;
    //rosasco image
    //https://marvel-b1-cdn.bc0a.com/f00000000181213/www.valpo.edu/computing-information-sciences/files/2015/02/20150204-JLH-Nick-Rosasco-004-800x800.jpg
    Image pic=new Image("https://marvel-b1-cdn.bc0a.com/f00000000181213/www.valpo.edu/computing-information-sciences/files/2015/02/20150204-JLH-Nick-Rosasco-004-800x800.jpg");
    Canvas canvas =new Canvas(pic.getHeight(),pic.getWidth());

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        FileChooser choose=new FileChooser();


        //main objects
        Group group=new Group();
        Scene scene = new Scene(group, pic.getHeight(), pic.getWidth());
        canvas.setHeight(pic.getHeight());
        canvas.setWidth(pic.getWidth());
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.drawImage(pic,0,25);
        Stage stage1=new Stage();
        group.getChildren().addAll(canvas);


        //making buttons and menus
        MenuItem help=new MenuItem("help");
        MenuItem closeButton=new MenuItem("Close");
        MenuItem saveButton=new MenuItem("Save");
        MenuItem saveAsButton=new MenuItem("Save As");
        MenuItem blue=new MenuItem("Blue");
        MenuItem red=new MenuItem("Red");
        MenuItem black=new MenuItem("Black");
        MenuItem rgb=new MenuItem("Choose..."); //soon...
        MenuItem Width1=new MenuItem("1");
        MenuItem Width2=new MenuItem("2");
        MenuItem Width3=new MenuItem("3");
        width=1;
        Menu penColor=new Menu("Pen");
        Menu Menu1=new Menu("File");
        Menu penWidth=new Menu("Width");
        MenuBar bart =new MenuBar();
        bart.getMenus().addAll(Menu1,penColor,penWidth);
        penColor.getItems().addAll(blue,red,black,rgb);
        penWidth.getItems().addAll(Width1,Width2,Width3);
        Menu1.getItems().addAll(closeButton,saveButton,saveAsButton,help);

        group.getChildren().add(bart);

        help.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                stage1.show();
            }
        });

        //button methods
        Width3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                width=3;
            }
        });
        Width2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                width=2;
            }
        });
        Width1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                width=1;
            }
        });
        saveAsButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                saveAsImage();//saves the image in imageview to this file location
            }
        });
        EventHandler<ActionEvent> event =new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                stage.close();//closes the scene
            }
        };
        EventHandler<ActionEvent> saving =new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                saveImage(pic);
            }
        };

        //creates black rectangles of size width on mouse click-drag
        canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED,
                new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent e) {
                        gc.strokeRect(e.getX() - 2, e.getY() - 2, width, width);
                    }
                });

        stage.setScene(scene);
        stage.show();

        closeButton.setOnAction(event);
        saveButton.setOnAction(saving);

    }



   private void saveImage(Image image){
        File f= new File("C:/250/New_File.png"); //creates a new file with this default location
        BufferedImage bImage=SwingFXUtils.fromFXImage(image,null); //gets the image from the canvas
        try{
            ImageIO.write(bImage,"png",f); //writes the image to the file
        }catch(IOException e){
            throw new RuntimeException(e);
        }
    }
    private void saveAsImage(){
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PNG Files", "*.png"),
                new FileChooser.ExtensionFilter("JPG Files", "*.jpg"),
                new FileChooser.ExtensionFilter("BMP Files", "*.bmp")
        );
        File f = fileChooser.showSaveDialog(null);

        if (f != null) {
            String extension = getExtension(f.getName());
            WritableImage wImage= new WritableImage((int) canvas.getWidth(),(int) canvas.getHeight());
            BufferedImage bImage=new BufferedImage((int)canvas.getWidth(),(int) canvas.getHeight(),BufferedImage.TYPE_INT_RGB);
            canvas.snapshot(null,wImage);
            System.out.println(extension);
            try {
                // AAAAAAAAA WHY DONT YOU WORK
                if ("png".equalsIgnoreCase(extension)) {
                    ImageIO.write(SwingFXUtils.fromFXImage(wImage, bImage), "png", f);
                } else if ("jpg".equalsIgnoreCase(extension)) {
                    ImageIO.write(SwingFXUtils.fromFXImage(wImage, bImage), "jpg", f);
                } else if ("bmp".equalsIgnoreCase(extension)) {
                    ImageIO.write(SwingFXUtils.fromFXImage(wImage, bImage), "bmp", f);
                } else {
                    // Handle unsupported formats
                    System.err.println("Unsupported format: " + extension);
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    private String getExtension(String fileName) {
        int lastDotIndex = fileName.lastIndexOf(".");
        if (lastDotIndex > 0 && lastDotIndex < fileName.length() - 1) {
            return fileName.substring(lastDotIndex + 1).toLowerCase();
        }
        return "png"; // Default to PNG if extension is not recognized
    }
    public static void main(String[] args) {
        launch(args);
    }
}

